/*
* Copyright (c) 2011 Samsung Electronics Co., Ltd All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License. 
*/

#include <tet_api.h>
#include <media/player.h>
#include <glib.h>

#define MEDIA_PATH "/mnt/nfs/Helicopter.mp4"
#define SUBTITLE_FILE_PATH "/opt/apps/com.samsung.apidemo/res/images/msg.smi"
#define PROGRESSIVE_DOWNLOAD_PATH "/opt/usr/media/Downloads/"
#define COOKIE_EXAMPLE "cookie example"

enum {
	POSITIVE_TC_IDX = 0x01,
	NEGATIVE_TC_IDX,
};

//keeping ret and player global, since using startup function for all
player_h player;
int sRet;

static void startup(void);
static void cleanup(void);

void (*tet_startup)(void) = startup;
void (*tet_cleanup)(void) = cleanup;

static void utc_media_player_get_duration_p(void);
static void utc_media_player_get_duration_n(void);
static void utc_media_player_set_position_p(void);
static void utc_media_player_set_position_n(void);
static void utc_media_player_get_position_p(void);
static void utc_media_player_get_position_n(void);
static void utc_media_player_set_position_ratio_p(void);
static void utc_media_player_set_position_ratio_n(void);
static void utc_media_player_get_position_ratio_p(void);
static void utc_media_player_get_position_ratio_n(void);
static void utc_media_player_get_state_p(void);
static void utc_media_player_get_state_n(void);
static void utc_media_player_get_video_size_p(void);
static void utc_media_player_get_video_size_n(void);
static void utc_media_player_set_looping_p(void);
static void utc_media_player_set_looping_n(void);
static void utc_media_player_is_looping_p(void);
static void utc_media_player_is_looping_n(void);
static void utc_media_player_set_mute_p(void);
static void utc_media_player_set_mute_n(void);
static void utc_media_player_is_muted_p(void);
static void utc_media_player_is_muted_n(void);
static void utc_media_player_set_display_p(void);
static void utc_media_player_set_display_n(void);
static void utc_media_player_set_memory_buffer_p(void);
static void utc_media_player_set_memory_buffer_n(void);
static void utc_media_player_set_volume_p(void);
static void utc_media_player_set_volume_n(void);
static void utc_media_player_get_volume_p(void);
static void utc_media_player_get_volume_n(void);
static void utc_media_player_set_sound_type_p(void);
static void utc_media_player_set_sound_type_n(void);
static void utc_media_player_set_subtitle_path_p(void);
static void utc_media_player_set_subtitle_path_n(void);
static void utc_media_player_set_x11_display_visible_p(void);
static void utc_media_player_set_x11_display_visible_n(void);
static void utc_media_player_is_x11_display_visible_p(void);
static void utc_media_player_is_x11_display_visible_n(void);
static void utc_media_player_set_x11_display_rotation_p(void);
static void utc_media_player_set_x11_display_rotation_n(void);
static void utc_media_player_get_x11_display_rotation_p(void);
static void utc_media_player_get_x11_display_rotation_n(void);
static void utc_media_player_set_x11_display_zoom_p(void);
static void utc_media_player_set_x11_display_zoom_n(void);
static void utc_media_player_get_x11_display_zoom_p(void);
static void utc_media_player_get_x11_display_zoom_n(void);
static void utc_media_player_set_display_mode_p(void);
static void utc_media_player_set_display_mode_n(void);
static void utc_media_player_get_display_mode_p(void);
static void utc_media_player_get_display_mode_n(void);
static void utc_media_player_capture_video_p(void);
static void utc_media_player_capture_video_n(void);
static void utc_media_player_is_display_mode_changeable_p(void);
static void utc_media_player_is_display_mode_changeable_n(void);
static void utc_media_player_set_playback_rate_p(void);
static void utc_media_player_set_playback_rate_n(void);
static void utc_media_player_set_subtitle_position_p(void);
static void utc_media_player_set_subtitle_position_n(void);
static void utc_media_player_set_progressive_download_path_p(void);
static void utc_media_player_set_progressive_download_path_n(void);
static void utc_media_player_get_progressive_download_status_p(void);
static void utc_media_player_get_progressive_download_status_n(void);
static void utc_media_player_set_streaming_cookie_p(void);
static void utc_media_player_set_streaming_cookie_n(void);
static void utc_media_player_get_streaming_download_progress_p(void);
static void utc_media_player_get_streaming_download_progress_n(void);
static void utc_media_player_audio_effect_set_value_p(void);
static void utc_media_player_audio_effect_set_value_n(void);
static void utc_media_player_audio_effect_get_value_p(void);
static void utc_media_player_audio_effect_get_value_n(void);
static void utc_media_player_audio_effect_clear_p(void);
static void utc_media_player_audio_effect_clear_n(void);
static void utc_media_player_audio_effect_get_value_range_p(void);
static void utc_media_player_audio_effect_get_value_range_n(void);
static void utc_media_player_audio_effect_is_available_p(void);
static void utc_media_player_audio_effect_is_available_n(void);
static void utc_media_player_audio_effect_foreach_supported_effect_p(void);
static void utc_media_player_audio_effect_foreach_supported_effect_n(void);
static void utc_media_player_audio_effect_set_preset_p(void);
static void utc_media_player_audio_effect_set_preset_n(void);
static void utc_media_player_audio_effect_preset_is_available_p(void);
static void utc_media_player_audio_effect_preset_is_available_n(void);
static void utc_media_player_audio_effect_foreach_supported_preset_p(void);
static void utc_media_player_audio_effect_foreach_supported_preset_n(void);
static void utc_media_player_audio_effect_get_equalizer_bands_count_p(void);
static void utc_media_player_audio_effect_get_equalizer_bands_count_n(void);
static void utc_media_player_audio_effect_set_equalizer_band_level_p(void);
static void utc_media_player_audio_effect_set_equalizer_band_level_n(void);
static void utc_media_player_audio_effect_get_equalizer_band_level_p(void);
static void utc_media_player_audio_effect_get_equalizer_band_level_n(void);
static void utc_media_player_audio_effect_get_equalizer_level_range_p(void);
static void utc_media_player_audio_effect_get_equalizer_level_range_n(void);
static void utc_media_player_audio_effect_equalizer_is_available_p(void);
static void utc_media_player_audio_effect_equalizer_is_available_n(void);
static void utc_media_player_audio_effect_set_equalizer_all_bands_p(void);
static void utc_media_player_audio_effect_set_equalizer_all_bands_n(void);
static void utc_media_player_audio_effect_equalizer_clear_p(void);
static void utc_media_player_audio_effect_equalizer_clear_n(void);
static void utc_media_player_enable_evas_display_scaling_p(void);
static void utc_media_player_enable_evas_display_scaling_n(void);
static void utc_media_player_get_content_info_p(void);
static void utc_media_player_get_content_info_n(void);
static void utc_media_player_get_codec_info_p(void);
static void utc_media_player_get_codec_info_n(void);
static void utc_media_player_get_audio_stream_info_p(void);
static void utc_media_player_get_audio_stream_info_n(void);
static void utc_media_player_get_album_art_p(void);
static void utc_media_player_get_album_art_n(void);
static void utc_media_player_get_track_count_p(void);
static void utc_media_player_get_track_count_n(void);

struct tet_testlist tet_testlist[] = {
	{ utc_media_player_get_duration_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_duration_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_position_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_position_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_position_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_position_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_position_ratio_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_position_ratio_n  , NEGATIVE_TC_IDX },
	{ utc_media_player_get_position_ratio_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_position_ratio_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_state_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_state_n  , NEGATIVE_TC_IDX },
	{ utc_media_player_get_video_size_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_video_size_n  , NEGATIVE_TC_IDX },
	{ utc_media_player_set_looping_p  , POSITIVE_TC_IDX },
	{ utc_media_player_set_looping_n , NEGATIVE_TC_IDX },
	{ utc_media_player_is_looping_p , POSITIVE_TC_IDX },
	{ utc_media_player_is_looping_n  , NEGATIVE_TC_IDX },
	{ utc_media_player_set_mute_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_mute_n , NEGATIVE_TC_IDX },
	{ utc_media_player_is_muted_p  , POSITIVE_TC_IDX },
	{ utc_media_player_is_muted_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_display_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_display_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_volume_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_volume_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_volume_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_volume_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_sound_type_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_sound_type_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_subtitle_path_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_subtitle_path_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_x11_display_visible_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_x11_display_visible_n , NEGATIVE_TC_IDX },
	{ utc_media_player_is_x11_display_visible_p , POSITIVE_TC_IDX },
	{ utc_media_player_is_x11_display_visible_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_x11_display_rotation_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_x11_display_rotation_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_x11_display_rotation_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_x11_display_rotation_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_x11_display_zoom_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_x11_display_zoom_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_x11_display_zoom_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_x11_display_zoom_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_display_mode_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_display_mode_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_display_mode_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_display_mode_n , NEGATIVE_TC_IDX },
	{ utc_media_player_capture_video_p , POSITIVE_TC_IDX },
	{ utc_media_player_capture_video_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_memory_buffer_p  , POSITIVE_TC_IDX },
	{ utc_media_player_set_memory_buffer_n, NEGATIVE_TC_IDX },
	{ utc_media_player_is_display_mode_changeable_p, POSITIVE_TC_IDX },
	{ utc_media_player_is_display_mode_changeable_n, NEGATIVE_TC_IDX },
	{ utc_media_player_set_playback_rate_p  , POSITIVE_TC_IDX },
	{ utc_media_player_set_playback_rate_n, NEGATIVE_TC_IDX },
	{ utc_media_player_set_subtitle_position_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_subtitle_position_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_progressive_download_path_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_progressive_download_path_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_progressive_download_status_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_progressive_download_status_n , NEGATIVE_TC_IDX },
	{ utc_media_player_set_streaming_cookie_p , POSITIVE_TC_IDX },
	{ utc_media_player_set_streaming_cookie_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_streaming_download_progress_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_streaming_download_progress_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_value_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_value_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_value_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_value_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_clear_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_clear_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_value_range_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_value_range_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_is_available_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_is_available_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_foreach_supported_effect_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_foreach_supported_effect_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_preset_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_preset_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_preset_is_available_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_preset_is_available_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_foreach_supported_preset_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_foreach_supported_preset_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_bands_count_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_bands_count_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_equalizer_band_level_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_equalizer_band_level_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_band_level_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_band_level_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_level_range_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_get_equalizer_level_range_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_equalizer_is_available_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_equalizer_is_available_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_equalizer_all_bands_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_set_equalizer_all_bands_n , NEGATIVE_TC_IDX },
	{ utc_media_player_audio_effect_equalizer_clear_p , POSITIVE_TC_IDX },
	{ utc_media_player_audio_effect_equalizer_clear_n , NEGATIVE_TC_IDX },
	{ utc_media_player_enable_evas_display_scaling_p , POSITIVE_TC_IDX },
	{ utc_media_player_enable_evas_display_scaling_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_content_info_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_content_info_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_codec_info_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_codec_info_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_audio_stream_info_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_audio_stream_info_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_album_art_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_album_art_n , NEGATIVE_TC_IDX },
	{ utc_media_player_get_track_count_p , POSITIVE_TC_IDX },
	{ utc_media_player_get_track_count_n , NEGATIVE_TC_IDX },
	{ NULL, 0 },
};

static GMainLoop *g_mainloop = NULL;
static GThread *event_thread;

gpointer GmainThread(gpointer data){
	g_mainloop = g_main_loop_new (NULL, 0);
	g_main_loop_run (g_mainloop);
	
	return NULL;
}

static void startup(void)
{
	if( !g_thread_supported() )
	{
		g_thread_init(NULL);
	}
	
	GError *gerr = NULL;
	event_thread = g_thread_create(GmainThread, NULL, 1, &gerr);

	if ((sRet = player_create(&player)) == PLAYER_ERROR_NONE)
	{
		sRet = player_set_uri(player, MEDIA_PATH);
	}
}

static void cleanup(void)
{
	player_destroy(player);
	g_main_loop_quit (g_mainloop);
	g_thread_join(event_thread);

}

typedef struct {
	char *album;
	char *artist;
	char *author;
	char *genre;
	char *title;
	char *year;
 	char *audio_codec;
	char *video_codec;
	int audio_sample_rate;
	int audio_channel;
	int audio_bit_rate;
	void *album_art;
	int album_art_size;
	int audio_tracks_count;
} t_streamInfo;

static t_streamInfo stream_info = {0};

static void player_video_capture_cb(unsigned char *data, int width, int height, unsigned int size, void *user_data)
{
	dts_message("Player", "player_video_capture_cb!!!");
}

static void _player_audio_effect_supported_effect_cb(audio_effect_e effect, void *user_data)
{
	dts_message("Player", " player_audio_effect_supported_effect_cb");
}

static void _player_audio_effect_supported_preset_cb(audio_effect_preset_e preset, void *user_data)
{
	dts_message("Player", " player_audio_effect_supported_preset_cb");
}

static void reset(void)
{
	if ((sRet = player_unprepare(player)) == PLAYER_ERROR_NONE)
	{
		sRet = player_set_uri(player, MEDIA_PATH);
	}
}

static void utc_media_player_get_duration_p(void)
{
	char* api_name = "player_get_duration";
	int ret;
	int duration;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{			
				if ((ret = player_get_duration(player, &duration)) == PLAYER_ERROR_NONE)
				{
					player_stop(player);
					reset();
					dts_pass(api_name);
				}
				if ((sRet = player_stop(player)) == PLAYER_ERROR_NONE)
				{
					dts_message(api_name, "Call log: %d %d", sRet, ret);
				}
			}
			reset();
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_duration_n(void)
{
	char* api_name = "player_get_duration";
	int ret;
	int duration;
	reset();
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_duration(player, &duration)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_position_p(void)
{
	char* api_name = "utc_media_player_set_position_p";
	int ret;
	int position = 10000;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_position(player, position,NULL,NULL)) == PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
		}
		reset();
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_position_n(void)
{
	char* api_name = "utc_media_player_set_position_n";
	int ret;
	int position = 10000;
	player_h player1 = NULL;
	if ((ret = player_set_position(player1, position,NULL,NULL)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_position_p(void)
{
	char* api_name = "player_get_position";
	int ret;
	int position;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_get_position(player, &position)) == PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
		}
		reset();
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_position_n(void)
{
	char* api_name = "player_get_position";
	int ret;
	int position;
	player_h player1 = NULL;
	if ((ret = player_get_position(player1, &position)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_position_ratio_p(void)
{
	char* api_name = "utc_media_player_set_position_ratio_p";
	int ret;
	int pos_ratio = 10;

	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_position_ratio(player, pos_ratio,NULL,NULL)) == PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
		}
		reset();
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_position_ratio_n(void)
{
	char* api_name = "utc_media_player_set_position_ratio_n";
	int ret;
	int pos_ratio = 10;
	player_h player1 = NULL;
	if ((ret = player_get_position_ratio(player1, pos_ratio)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_position_ratio_p(void)
{
	char* api_name = "player_get_position_ratio";
	int ret;
	int pos_ratio;

	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_get_position_ratio(player, &pos_ratio)) == PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
		}
		reset();
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_position_ratio_n(void)
{
	char* api_name = "player_get_position_ratio";
	int ret;
	int pos_ratio;
	player_h player1 = NULL;
	if ((ret = player_get_position_ratio(player1, &pos_ratio)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_state_p(void)
{
	char* api_name = "player_get_state";
	int ret;
	player_state_e cur_state;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_get_state(player, &cur_state)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_state_n(void)
{
	char* api_name = "player_get_state";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_state(player, NULL)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_video_size_p(void)
{
	char* api_name = "player_get_video_size";
	int ret;
	int width, height;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		if ((ret = player_get_video_size(player, &width, &height)) == PLAYER_ERROR_NONE)
		{
			reset();
			dts_pass(api_name);
		}
		if ((sRet = player_unprepare(player)) == PLAYER_ERROR_NONE)
		{
			sRet = player_set_uri(player, MEDIA_PATH);
		} 
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_video_size_n(void)
{
	char* api_name = "player_get_video_size";
	int ret;
	int width, height;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_video_size(player, &width, &height)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_looping_p(void)
{
	char* api_name = "player_set_looping";
	int ret;
	bool looping = true;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_looping(player, looping)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_looping_n(void)
{
	char* api_name = "player_set_looping";
	int ret;
	bool looping = true;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_looping(NULL, looping)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_looping_p(void)
{
	char* api_name = "player_is_looping";
	int ret;
	bool looping;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_is_looping(player, &looping)) == PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
			reset();
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_looping_n(void)
{
	char* api_name = "player_is_looping";
	int ret;
	bool looping;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_is_looping(NULL, &looping)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_mute_p(void)
{
	char* api_name = "utc_media_player_set_mute_p";
	int ret;
	bool muted=false;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_mute(player, muted)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_mute_n(void)
{
	char* api_name = "utc_media_player_set_mute_n";
	int ret;
	player_h player1 = NULL;
	bool muted = false;
	if ((ret = player_set_mute(player1, muted)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}



static void utc_media_player_is_muted_p(void)
{
	char* api_name = "player_is_muted";
	int ret;
	bool muted;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		if ((ret = player_is_muted(player, &muted)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_muted_n(void)
{
	char* api_name = "player_is_muted";
	int ret;
	player_h player1 = NULL;
	bool muted;
	if ((ret = player_is_muted(player1, &muted)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_display_p(void)
{
	char* api_name = "player_set_display";
	int ret;
	reset();
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_display_n(void)
{
	char* api_name = "player_set_display";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_display(0,PLAYER_DISPLAY_TYPE_X11, 0)) != PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}
			reset();
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_memory_buffer_p(void)
{
	char* api_name = "utc_media_player_set_memory_buffer_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		GMappedFile *file;
		gsize file_size;
		guint8* g_media_mem = NULL;
		
		file = g_mapped_file_new (MEDIA_PATH, FALSE,NULL);
		file_size = g_mapped_file_get_length (file);
		g_media_mem = (guint8 *) g_mapped_file_get_contents (file);
		
		if ((ret = player_set_memory_buffer(player, (void*)g_media_mem ,file_size)) == PLAYER_ERROR_NONE)
		{
			player_prepare(player);
			reset();
			dts_pass(api_name);
		}
	} 
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_memory_buffer_n(void)
{
	char* api_name = "utc_media_player_set_memory_buffer_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_memory_buffer(player, NULL, 0)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_volume_p(void)
{
	char* api_name = "utc_media_player_set_volume_p";
	int ret;
	float left, right  = 1.0f; 
	{
		if (sRet == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_volume(player, left, right)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_volume_n(void)
{
	char* api_name = "utc_media_player_set_volume_n";
	int ret;
	float left, right  = 1.0f;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_volume(NULL, left, right)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_volume_p(void)
{
	char* api_name = "player_get_volume";
	int ret;
	float left, right;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_volume(player, &left, &right)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_volume_n(void)
{
	char* api_name = "player_get_volume";
	int ret;
	float left, right;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_volume(player, &left, NULL)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_sound_type_p(void)
{
	char* api_name = "utc_media_player_set_sound_type_p";
	int ret;
	sound_type_e sound_type = SOUND_TYPE_MEDIA;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_sound_type(player,sound_type)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_sound_type_n(void)
{
	char* api_name = "utc_media_player_set_sound_type_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_sound_type(NULL, SOUND_TYPE_MEDIA)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_subtitle_path_p(void)
{
	char* api_name = "utc_media_player_set_subtitle_path_p";
	int ret;
	sound_type_e sound_type = SOUND_TYPE_MEDIA;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_subtitle_path(player,MEDIA_PATH)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_subtitle_path_n(void)
{
	char* api_name = "utc_media_player_set_subtitle_path_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_subtitle_path(NULL, NULL)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_visible_p(void)
{
	char* api_name = "utc_media_player_set_x11_display_visible_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_visible(player, true)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_visible_n(void)
{
	char* api_name = "utc_media_player_set_x11_display_visible_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_visible(NULL, true)) != PLAYER_ERROR_NONE)
			{ 
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_x11_display_visible_p(void)
{
	char* api_name = "utc_media_player_is_x11_display_visible_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			bool isVisible;
			if ((ret = player_is_x11_display_visible(player, &isVisible)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_x11_display_visible_n(void)
{
	char* api_name = "utc_media_player_is_x11_display_visible_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_is_x11_display_visible(NULL, NULL)) != PLAYER_ERROR_NONE)
			{ 
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_rotation_p(void)
{
	char* api_name = "utc_media_player_set_x11_display_rotation_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_rotation(player, PLAYER_DISPLAY_ROTATION_180)) == PLAYER_ERROR_NONE)
			{ 
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_rotation_n(void)
{
	char* api_name = "utc_media_player_set_x11_display_rotation_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_rotation(NULL, PLAYER_DISPLAY_ROTATION_180)) != PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_zoom_p(void)
{
	char* api_name = "utc_media_player_set_x11_display_zoom_p";
	int ret;
	int level;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_zoom(player, 1)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_x11_display_zoom(player, &level)) == PLAYER_ERROR_NONE)
				{
					if (1 == level)
					{
						dts_pass(api_name);
					}
				}
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_x11_display_zoom_n(void)
{
	char* api_name = "utc_media_player_set_x11_display_zoom_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_rotation(player, 15)) != PLAYER_ERROR_NONE)//outside of the scope
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_x11_display_zoom_p(void)
{
	char* api_name = "utc_media_player_get_x11_display_zoom_p";
	int ret;
	int level;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_x11_display_zoom(player, 1)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_x11_display_zoom(player, &level)) == PLAYER_ERROR_NONE)
				{
					if (1 == level)
					{
						dts_pass(api_name);
					}
				}
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_x11_display_zoom_n(void)
{
	char* api_name = "utc_media_player_get_x11_display_zoom_n";
	int ret;
	int level;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_get_x11_display_rotation(NULL, &level)) != PLAYER_ERROR_NONE)//outside of the scope
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_x11_display_rotation_p(void)
{
	char* api_name = "utc_media_player_get_x11_display_rotation_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			player_display_rotation_e rotation;
			if ((ret = player_get_x11_display_rotation(player, &rotation)) == PLAYER_ERROR_NONE)
			{ 
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_x11_display_rotation_n(void)
{
	char* api_name = "utc_media_player_get_x11_display_rotation_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_x11_display_rotation(NULL, PLAYER_DISPLAY_ROTATION_180)) != PLAYER_ERROR_NONE)
		{
				dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_display_mode_p(void)
{
	char* api_name = "utc_media_player_set_display_mode_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_display_mode(player, PLAYER_DISPLAY_MODE_FULL_SCREEN)) == PLAYER_ERROR_NONE)
			{ 
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_display_mode_n(void)
{
	char* api_name = "utc_media_player_set_display_mode_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_display_mode(NULL, PLAYER_DISPLAY_MODE_FULL_SCREEN)) != PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_display_mode_p(void)
{
	char* api_name = "utc_media_player_get_display_mode_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			player_display_mode_e mode;
			if ((ret = player_get_display_mode(player, &mode)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_display_mode_n(void)
{
	char* api_name = "utc_media_player_get_display_mode_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_get_display_mode(NULL, PLAYER_DISPLAY_MODE_FULL_SCREEN)) != PLAYER_ERROR_NONE)
		{
				dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_capture_video_p(void)
{
	char* api_name = "utc_media_player_capture_video_p";
	int ret;

	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_capture_video(player,player_video_capture_cb ,NULL)) == PLAYER_ERROR_NONE)
				{
					player_stop(player);
					reset();
					dts_pass(api_name);
				}
				if ((sRet = player_stop(player)) == PLAYER_ERROR_NONE)
				{
					dts_message(api_name, "Call log: %d %d", sRet, ret);
				}
			}
			reset();
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_capture_video_n(void)
{
	char* api_name = "utc_media_player_capture_video_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_capture_video(NULL,player_video_capture_cb ,NULL)) != PLAYER_ERROR_NONE)
		{
				dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_display_mode_changeable_p(void)
{
	char* api_name = "utc_media_player_is_display_mode_changeable_p";
	bool changeable;
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_X11,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_set_display_mode(player, PLAYER_DISPLAY_MODE_FULL_SCREEN)) == PLAYER_ERROR_NONE)
			{
				ret = player_is_display_mode_changeable(player, &changeable);
				if((ret == PLAYER_ERROR_NONE) && (changeable == true))
				{
					dts_pass(api_name);
				}

			}
			else
				ret = player_is_display_mode_changeable(player, &changeable);
				if((ret == PLAYER_ERROR_NONE) || (changeable == false))
				{
					dts_message(api_name, "Call log: %d %d", sRet, ret);
					dts_fail(api_name);
				}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_is_display_mode_changeable_n(void)
{
	char* api_name = "utc_media_player_is_display_mode_changeable_n";
	bool changeable;
	int ret;
	ret = player_is_display_mode_changeable(NULL, &changeable);
	if(ret != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}

	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_playback_rate_p(void)
{
	char* api_name = "utc_media_player_set_playback_rate_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		int retprep = player_prepare(player);
			{
			if ((ret = player_set_sound_type(player, SOUND_TYPE_MEDIA)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_set_playback_rate(player, 2.0)) == PLAYER_ERROR_NONE)
					{
						dts_pass(api_name);
					}
				player_stop(player);
				}
			}
			reset();
		}
	}

	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_playback_rate_n(void)
{
	char* api_name = "utc_media_player_set_playback_rate_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		player_prepare(player);
		{
			if ((ret = player_set_sound_type(player, SOUND_TYPE_MEDIA)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_set_playback_rate(player, 10.0)) != PLAYER_ERROR_NONE)
					{
						dts_pass(api_name);
					}
				player_stop(player);
				}
			}
			reset();
		}
	}

	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_subtitle_position_p(void)
{
	char* api_name = "utc_media_player_set_subtitle_position_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
			{
			if ((ret = player_set_subtitle_path(player, SUBTITLE_FILE_PATH)) == PLAYER_ERROR_NONE)
			{
				player_prepare(player);
				if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
					{
						if ((ret = player_set_subtitle_position(player, 1000)) == PLAYER_ERROR_NONE)
						{
							dts_pass(api_name);
						}
						player_stop(player);
					}
				}
			reset();
			}
	}

	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_subtitle_position_n(void)
{
	char* api_name = "utc_media_player_set_subtitle_position_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_subtitle_position(player, -2000)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_progressive_download_path_p(void)
{
	char* api_name = "utc_media_player_set_progressive_download_path_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
			if ((ret = player_set_progressive_download_path(player, PROGRESSIVE_DOWNLOAD_PATH)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_progressive_download_path_n(void)
{
	char* api_name = "utc_media_player_set_progressive_download_path_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_progressive_download_path(player, NULL)) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_progressive_download_status_p(void)
{
	char* api_name = "utc_media_player_get_progressive_download_status_p";
	int ret;
	unsigned long *current;
	unsigned long *total_size;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		if ((ret = player_set_progressive_download_path(player, PROGRESSIVE_DOWNLOAD_PATH)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_prepare(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_get_progressive_download_status(player, current, total_size)) == PLAYER_ERROR_NONE)
					{
						dts_pass(api_name);
					}
					reset();
				}
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_progressive_download_status_n(void)
{
	char* api_name = "utc_media_player_get_progressive_download_status_n";
	int ret;
	unsigned long *current;
	unsigned long *total_size;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		if ((ret = player_prepare(player)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_get_progressive_download_status(player, current, total_size)) != PLAYER_ERROR_NONE)
			{
				reset();
				dts_pass(api_name);
			}

		}
		reset();
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_streaming_cookie_p(void)
{
	char* api_name = "utc_media_player_set_streaming_cookie_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{

		if ((ret = player_set_streaming_cookie(player, COOKIE_EXAMPLE, sizeof(COOKIE_EXAMPLE))) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_set_streaming_cookie_n(void)
{
	char* api_name = "utc_media_player_set_streaming_cookie_n";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_set_streaming_cookie(player, NULL, NULL)) != PLAYER_ERROR_NONE)
		{
			//reset();
			dts_pass(api_name);
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_streaming_download_progress_p(void)
{
	char* api_name = "utc_media_player_get_streaming_download_progress_p";
	int ret;
	int start;
	int current;
	if (sRet == PLAYER_ERROR_NONE)
	{
		if ((ret = player_prepare(player)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_streaming_download_progress(player, &start, &current)) == PLAYER_ERROR_NONE)
				{
					dts_pass(api_name);
				}
				player_stop(player);
				reset();
			}
		}

	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_streaming_download_progress_n(void)
{
	char* api_name = "utc_media_player_get_streaming_download_progress_n";
	int ret;
	int start;
	int current;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		if ((ret = player_prepare(player)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_get_streaming_download_progress(player, &start, &current)) != PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_value_p(void)
{
	char* api_name = "utc_media_player_audio_effect_set_value_p";
	int ret;
	int min, max, value;
	if ((ret = player_audio_effect_get_value_range(player, AUDIO_EFFECT_3D, &min, &max)) == PLAYER_ERROR_NONE)
	{
		if ((ret = player_audio_effect_set_value(player, AUDIO_EFFECT_3D, min + (int)(0.5*(max - min)))) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_audio_effect_get_value(player, AUDIO_EFFECT_3D, &value)) == PLAYER_ERROR_NONE)
			{
				if (value == (int)(0.5*(max - min)))
				{
					dts_pass(api_name);
				}
			}
		}
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_value_n(void)
{
	char* api_name = "utc_media_player_audio_effect_set_value_n";
	player_h local_player;
	int ret;
	int min, max, value;
	player_create(&local_player);
	if ((ret = player_audio_effect_get_value_range(local_player, AUDIO_EFFECT_3D, &min, &max)) == PLAYER_ERROR_NONE)
	{
		player_destroy(local_player);
		if ((ret = player_audio_effect_set_value(local_player, AUDIO_EFFECT_3D, min + (int)(0.5*(max - min)))) != PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_value_p(void)
{
	char* api_name = "utc_media_player_audio_effect_set_value_p";
	int ret;
	int min, max, value;
	if ((ret = player_audio_effect_get_value_range(player, AUDIO_EFFECT_3D, &min, &max)) == PLAYER_ERROR_NONE)
	{
		if ((ret = player_audio_effect_set_value(player, AUDIO_EFFECT_3D, min + (int)(0.5*(max - min)))) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_audio_effect_get_value(player, AUDIO_EFFECT_3D, &value)) == PLAYER_ERROR_NONE)
			{
				if (value == (int)(0.5*(max - min)))
				{
					dts_pass(api_name);
				}
			}
		}
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_value_n(void)
{
	char* api_name = "utc_media_player_audio_effect_set_value_n";
	player_h local_player;
	int ret;
	int min, max, value;
	player_create(&local_player);
	if ((ret = player_audio_effect_get_value_range(local_player, AUDIO_EFFECT_3D, &min, &max)) == PLAYER_ERROR_NONE)
	{
		if ((ret = player_audio_effect_set_value(local_player, AUDIO_EFFECT_3D, min + (int)(0.5*(max - min)))) == PLAYER_ERROR_NONE)
		{
			player_destroy(local_player);
			if ((ret = player_audio_effect_get_value(local_player, AUDIO_EFFECT_3D, &value)) != PLAYER_ERROR_NONE)
			{
			dts_pass(api_name);
			}
		}
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_clear_p(void)
{
	char* api_name = "utc_media_player_audio_effect_clear_p";
	int ret;
	int value;
	if ((ret = player_audio_effect_clear(player, AUDIO_EFFECT_3D)) == PLAYER_ERROR_NONE)
	{
		if ((ret = player_audio_effect_get_value(player, AUDIO_EFFECT_3D, &value)) == PLAYER_ERROR_NONE)
		{
			if(0 == value)
			{
				dts_pass(api_name);
			}
		}
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_clear_n(void)
{
	char* api_name = "utc_media_player_audio_effect_clear_n";
	player_h local_player;
	int ret;
	if ((ret = player_audio_effect_clear(local_player, AUDIO_EFFECT_3D)) != PLAYER_ERROR_NONE)
		{
		dts_pass(api_name);
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_value_range_p(void)
{
	char* api_name = "utc_media_player_audio_effect_get_value_range_p";
	int ret;
	int min, max;
	if ((ret = player_audio_effect_get_value_range(player, AUDIO_EFFECT_3D, &min, &max)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_value_range_n(void)
{
	char* api_name = "utc_media_player_audio_effect_get_value_range_n";
	player_h local_player;
	int ret;
	int min, max;
	if ((ret = player_audio_effect_get_value_range(local_player, AUDIO_EFFECT_3D, &min, &max)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_is_available_p(void)
{
	char* api_name = "utc_media_player_audio_effect_is_available_p";
	int ret;
	bool available;
	if ((ret = player_audio_effect_is_available(player, AUDIO_EFFECT_3D, &available)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_is_available_n(void)
{
	char* api_name = "utc_media_player_audio_effect_is_available_n";
	player_h local_player;
	int ret;
	bool available;
	if ((ret = player_audio_effect_is_available(local_player, AUDIO_EFFECT_3D, &available)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_foreach_supported_effect_p(void)
{
	char* api_name = "utc_media_player_audio_effect_foreach_supported_effect_p";
	int ret;
	if ((ret = player_audio_effect_foreach_supported_effect(player, _player_audio_effect_supported_effect_cb, NULL)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_foreach_supported_effect_n(void)
{
	char* api_name = "utc_media_player_audio_effect_foreach_supported_effect_n";
	player_h local_player;
	int ret;
	if ((ret = player_audio_effect_foreach_supported_effect(local_player, NULL, NULL)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_preset_p(void)
{
	char* api_name = "utc_media_player_audio_effect_set_preset_p";
	int ret;
	if ((ret = player_audio_effect_set_preset(player, AUDIO_EFFECT_PRESET_AUTO)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_preset_n(void)
{
	char* api_name = "utc_media_player_audio_effect_set_preset_n";
	player_h local_player;
	int ret;
	if ((ret = player_audio_effect_set_preset(local_player, AUDIO_EFFECT_PRESET_AUTO)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_preset_is_available_p(void)
{
	char* api_name = "utc_media_player_audio_effect_preset_is_available_p";
	int ret;
	bool available;
	if ((ret = player_audio_effect_preset_is_available(player, AUDIO_EFFECT_PRESET_AUTO, &available)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_preset_is_available_n(void)
{
	char* api_name = "utc_media_player_audio_effect_preset_is_available_n";
	player_h local_player;
	int ret;
	bool available;
	if ((ret = player_audio_effect_preset_is_available(local_player, AUDIO_EFFECT_PRESET_AUTO, &available)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}

	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_foreach_supported_preset_p(void)
{
	char* api_name = "utc_media_player_audio_effect_foreach_supported_preset_p";
	int ret;
	if ((ret = player_audio_effect_foreach_supported_preset(player, _player_audio_effect_supported_preset_cb, NULL)) == PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_foreach_supported_preset_n(void)
{
	char* api_name = "utc_media_player_audio_effect_foreach_supported_effect_n";
	player_h local_player;
	int ret;
	if ((ret = player_audio_effect_foreach_supported_preset(local_player, NULL, NULL)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_bands_count_p(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_bands_count_p";
	int ret;
	int count;
	bool available;

	if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
	{
		if (true == available)
		{
			if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_bands_count_n(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_bands_count_n";
	player_h local_player;
	int ret;
	int count;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_bands_count(local_player, &count)) != PLAYER_ERROR_NONE)
				{
					dts_pass(api_name);
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_equalizer_band_level_p(void)
{
	char* api_name = "utc_media_player_audio_effect_set_equalizer_band_level_p";
	int ret;
	int count, min, max, level;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_audio_effect_get_equalizer_level_range(player, &min, &max)) == PLAYER_ERROR_NONE)
					{
						if ((ret = player_audio_effect_set_equalizer_band_level(player, count/2, min)) == PLAYER_ERROR_NONE)
						{
							if ((ret = player_audio_effect_get_equalizer_band_level(player, count/2, &level)) == PLAYER_ERROR_NONE)
							{
								if (level == min)
								{
									dts_pass(api_name);
								}
							}
						}
					}
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_equalizer_band_level_n(void)
{
	char* api_name = "utc_media_player_audio_effect_set_equalizer_band_level_n";
	player_h local_player;
	int ret;
	int count, min, max;
	bool available;
	player_create(&local_player);
	if ((ret = player_audio_effect_equalizer_is_available(local_player, &available)) == PLAYER_ERROR_NONE)
	{
		if (true == available)
		{
			if ((ret = player_audio_effect_get_equalizer_bands_count(local_player, &count)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_audio_effect_get_equalizer_level_range(local_player, &min, &max)) == PLAYER_ERROR_NONE)
				{
					player_destroy(local_player);
					if ((ret = player_audio_effect_set_equalizer_band_level(local_player, count/2, min)) != PLAYER_ERROR_NONE)
					{
						dts_pass(api_name);
					}
				}
			}
		}
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_band_level_p(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_band_level_p";
	int ret;
	int count, min, max, level;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_audio_effect_get_equalizer_level_range(player, &min, &max)) == PLAYER_ERROR_NONE)
					{
						if ((ret = player_audio_effect_set_equalizer_band_level(player, count/2, min)) == PLAYER_ERROR_NONE)
						{
							if ((ret = player_audio_effect_get_equalizer_band_level(player, count/2, &level)) == PLAYER_ERROR_NONE)
							{
								if (level == min)
								{
									dts_pass(api_name);
								}
							}
						}
					}
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_band_level_n(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_band_level_n";
	player_h local_player;
	int ret;
	int count, min, max, level;
	bool available;
	player_create(&local_player);
	if ((ret = player_audio_effect_equalizer_is_available(local_player, &available)) == PLAYER_ERROR_NONE)
	{
		if (true == available)
		{
			if ((ret = player_audio_effect_get_equalizer_bands_count(local_player, &count)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_audio_effect_get_equalizer_level_range(local_player, &min, &max)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_audio_effect_set_equalizer_band_level(local_player, count/2, min)) == PLAYER_ERROR_NONE)
					{
						player_destroy(local_player);
						if ((ret = player_audio_effect_get_equalizer_band_level(local_player, count/2, level)) != PLAYER_ERROR_NONE)
						{
							dts_pass(api_name);
						}
					}
				}
			}
		}
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_level_range_p(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_level_range_p";
	int ret;
	int min, max;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_level_range(player, &min, &max)) == PLAYER_ERROR_NONE)
				{
					dts_pass(api_name);
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_get_equalizer_level_range_n(void)
{
	char* api_name = "utc_media_player_audio_effect_get_equalizer_level_range_n";
	player_h local_player;
	int ret;
	int min, max;
	bool available;
	player_create(&local_player);
	if ((ret = player_audio_effect_equalizer_is_available(local_player, &available)) == PLAYER_ERROR_NONE)
	{
		if (true == available)
		{
			player_destroy(local_player);
			if ((ret = player_audio_effect_get_equalizer_level_range(local_player, &min, &max)) == PLAYER_ERROR_NONE)
			{
				dts_pass(api_name);
			}
		}
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_equalizer_is_available_p(void)
{
	char* api_name = "utc_media_player_audio_effect_equalizer_is_available_p";
	int ret;
	bool available;
		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			dts_pass(api_name);
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_equalizer_is_available_n(void)
{
	char* api_name = "utc_media_player_audio_effect_equalizer_is_available_n";
	player_h local_player;
	int ret;
	bool available;
	if ((ret = player_audio_effect_equalizer_is_available(local_player, &available)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_equalizer_all_bands_p(void)
{
	char* api_name = "utc_media_player_audio_effect_set_equalizer_all_bands_p";
	int ret, i;
	int count, min, max, level;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_audio_effect_get_equalizer_level_range(player, &min, &max)) == PLAYER_ERROR_NONE)
					{
						int *band_levels = (int*)malloc(sizeof(int) * count);
						for(i=0;i<count;i++)
							band_levels[i] = min;
						if ((ret = player_audio_effect_set_equalizer_all_bands(player, band_levels, count)) == PLAYER_ERROR_NONE)
						{
							for(i=0;i<count;i++)
							{
								if ((ret = player_audio_effect_get_equalizer_band_level(player, i, &level)) == PLAYER_ERROR_NONE)
								{
									if (level != min)
									{
										dts_fail(api_name);
									}
								}
							}
							dts_pass(api_name);
						}
						free(band_levels);
					}
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_set_equalizer_all_bands_n(void)
{
	char* api_name = "utc_media_player_audio_effect_set_equalizer_all_bands_n";
	int ret, i;
		int count, min, max, level;
		bool available;

			if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
			{
				if (true == available)
				{
					if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
					{
						if ((ret = player_audio_effect_get_equalizer_level_range(player, &min, &max)) == PLAYER_ERROR_NONE)
						{
							int *band_levels = (int*)malloc(sizeof(int) * count);
							for(i=0;i<count;i++)
								band_levels[i] = min;
							if ((ret = player_audio_effect_set_equalizer_all_bands(player, band_levels, count + 5)) != PLAYER_ERROR_NONE)
							{
								dts_pass(api_name);
							}
							free(band_levels);
						}
					}
				}
			}
		dts_message(api_name, "Call log: %d", ret);
		dts_fail(api_name);
}

static void utc_media_player_audio_effect_equalizer_clear_p(void)
{
	char* api_name = "utc_media_player_audio_effect_equalizer_clear_p";
	int ret, i;
	int count, min, max, level;
	bool available;

		if ((ret = player_audio_effect_equalizer_is_available(player, &available)) == PLAYER_ERROR_NONE)
		{
			if (true == available)
			{
				if ((ret = player_audio_effect_get_equalizer_bands_count(player, &count)) == PLAYER_ERROR_NONE)
				{
					if ((ret = player_audio_effect_equalizer_clear(player)) == PLAYER_ERROR_NONE)
					{
						for(i=0;i<count;i++)
						{
							if ((ret = player_audio_effect_get_equalizer_band_level(player, i, &level)) == PLAYER_ERROR_NONE)
							{
								if (0 != level)
								{
									dts_fail(api_name);
								}
							}
						}
						dts_pass(api_name);
					}
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_audio_effect_equalizer_clear_n(void)
{
	char* api_name = "utc_media_player_audio_effect_equalizer_clear_n";
	player_h local_player;
	int ret;
	if ((ret = player_audio_effect_equalizer_clear(local_player)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}


static void utc_media_player_enable_evas_display_scaling_p(void)
{
	char* api_name = "utc_media_player_enable_evas_display_scaling_p";
	int ret;
	bool changeable;
	if ((ret = player_set_display(player, PLAYER_DISPLAY_TYPE_EVAS,0)) == PLAYER_ERROR_NONE)
		{
			if ((ret = player_enable_evas_display_scaling(player, false)) == PLAYER_ERROR_NONE)
			{
				if ((ret =  player_is_display_mode_changeable(player, &changeable)) == PLAYER_ERROR_NONE)
				{
					if (false == changeable)
					{
						dts_pass(api_name);
					}
				}
			}
		}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_enable_evas_display_scaling_n(void)
{
	char* api_name = "utc_media_player_enable_evas_display_scaling_n";
	player_h local_player;
	int ret;
	bool changeable;
	if ((ret = player_enable_evas_display_scaling(local_player, true)) != PLAYER_ERROR_NONE)
	{
		dts_pass(api_name);
	}
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_get_content_info_p(void)
{
	char* api_name = "utc_media_player_get_content_info_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_ALBUM, &stream_info.album)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_ARTIST, &stream_info.artist)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_AUTHOR, &stream_info.author)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_GENRE, &stream_info.genre)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_TITLE, &stream_info.title)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				if ((ret = player_get_content_info(player, PLAYER_CONTENT_INFO_YEAR, &stream_info.year)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				dts_pass(api_name);
				player_stop(player);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_content_info_n(void)
{
	char* api_name = "utc_media_player_get_content_info_n";
	player_h local_player;
	player_create(local_player);
	int ret;
	if ((ret = player_get_content_info(local_player, PLAYER_CONTENT_INFO_ALBUM, &stream_info.album)) != PLAYER_ERROR_NONE)
		dts_pass(api_name);
	player_destroy(local_player);
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_get_codec_info_p(void)
{
	char* api_name = "utc_media_player_get_codec_info_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_codec_info(player, &stream_info.audio_codec, &stream_info.video_codec)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				dts_pass(api_name);
				player_stop(player);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_codec_info_n(void)
{
	char* api_name = "utc_media_player_get_codec_info_n";
	player_h local_player;
	player_create(local_player);
	int ret;
	if ((ret = player_get_codec_info(local_player, &stream_info.audio_codec, &stream_info.video_codec)) != PLAYER_ERROR_NONE)
		dts_pass(api_name);
	player_destroy(local_player);
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_get_audio_stream_info_p(void)
{
	char* api_name = "utc_media_player_get_audio_stream_info_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_audio_stream_info(player, &stream_info.audio_sample_rate, &stream_info.audio_channel, &stream_info.audio_bit_rate)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				dts_pass(api_name);
				player_stop(player);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_audio_stream_info_n(void)
{
	char* api_name = "utc_media_player_get_audio_stream_info_n";
	player_h local_player;
	player_create(local_player);
	int ret;
	if ((ret = player_get_audio_stream_info(local_player, &stream_info.audio_sample_rate, &stream_info.audio_channel, &stream_info.audio_bit_rate)) != PLAYER_ERROR_NONE)
		dts_pass(api_name);
	player_destroy(local_player);
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_get_album_art_p(void)
{
	char* api_name = "utc_media_player_get_album_art_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_album_art(player, &stream_info.album_art, &stream_info.album_art_size)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				dts_pass(api_name);
				player_stop(player);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_album_art_n(void)
{
	char* api_name = "utc_media_player_get_album_art_n";
	player_h local_player;
	player_create(local_player);
	int ret;
	if ((ret = player_get_album_art(local_player, &stream_info.album_art, &stream_info.album_art_size)) != PLAYER_ERROR_NONE)
		dts_pass(api_name);
	player_destroy(local_player);
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}

static void utc_media_player_get_track_count_p(void)
{
	char* api_name = "utc_media_player_get_track_count_p";
	int ret;
	if (sRet == PLAYER_ERROR_NONE)
	{
		reset();
		player_prepare(player);
		{
			if ((ret = player_start(player)) == PLAYER_ERROR_NONE)
			{
				if ((ret = player_get_track_count(player, PLAYER_TRACK_TYPE_AUDIO, &stream_info.audio_tracks_count)) != PLAYER_ERROR_NONE)
					dts_fail(api_name);
				dts_pass(api_name);
				player_stop(player);
			}
		}
	}
	dts_message(api_name, "Call log: %d %d", sRet, ret);
	dts_fail(api_name);
}

static void utc_media_player_get_track_count_n(void)
{
	char* api_name = "utc_media_player_get_track_count_n";
	player_h local_player;
	player_create(local_player);
	int ret;
	if ((ret = player_get_track_count(local_player, PLAYER_TRACK_TYPE_AUDIO, &stream_info.audio_tracks_count)) != PLAYER_ERROR_NONE)
		dts_pass(api_name);
	player_destroy(local_player);
	dts_message(api_name, "Call log: %d", ret);
	dts_fail(api_name);
}
