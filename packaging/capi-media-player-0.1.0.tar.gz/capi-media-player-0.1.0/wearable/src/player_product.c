/*
* Copyright (c) 2011 Samsung Electronics Co., Ltd All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mm.h>
#include <mm_player.h>
#include <mm_player_internal.h>
#include <mm_types.h>
#include <player.h>
#include <player_private.h>
#include <dlog.h>
#include <player_product.h>
#include <gst/gst.h>

/*
* Internal Macros
*/
#define PLAYER_SET_CALLBACK(event_type, handle, callback, user_data) \
do \
{ \
	PLAYER_INSTANCE_CHECK(handle); \
	PLAYER_NULL_ARG_CHECK(callback); \
	handle->user_cb[event_type] = callback; \
	handle->user_data[event_type] = user_data; \
	LOGI("[%s] Event type : %d ",__FUNCTION__, event_type); \
}while(0)

/*
* Internal Implementation
*/
int player_set_playback_rate_ex(player_h player, float rate)
{
        LOGI("[%s] rate : %0.1f", __FUNCTION__, rate);
        PLAYER_INSTANCE_CHECK(player);
        PLAYER_CHECK_CONDITION(rate>=0.5 && rate <= 2.0 ,PLAYER_ERROR_INVALID_PARAMETER,"PLAYER_ERROR_INVALID_PARAMETER" );
        player_s * handle = (player_s *) player;

        if (!__player_state_validate(handle, PLAYER_STATE_READY))
        {
                LOGE("[%s] PLAYER_ERROR_INVALID_STATE(0x%08x) : current state - %d" ,__FUNCTION__,PLAYER_ERROR_INVALID_STATE, handle->state);
                return PLAYER_ERROR_INVALID_STATE;
        }

        int ret = mm_player_set_play_speed_ex(handle->mm_handle, rate);
        switch (ret)
        {
                case MM_ERROR_NONE:
                case MM_ERROR_PLAYER_NO_OP:
                        ret = PLAYER_ERROR_NONE;
                        break;
                default:
                        return __convert_error_code(ret,(char*)__FUNCTION__);
        }

        return ret;
}

int player_set_rich_audio(player_h player)
{
	LOGI("[%s]", __FUNCTION__);
	PLAYER_INSTANCE_CHECK(player);
	player_s * handle = (player_s *) player;
	PLAYER_STATE_CHECK(handle,PLAYER_STATE_IDLE);

	int ret = mm_player_set_rich_audio(handle->mm_handle);
	if(ret != MM_ERROR_NONE)
	{
		return __convert_error_code(ret,(char*)__FUNCTION__);
	}

	return ret;
}

int player_set_safety_volume(player_h player)
{
	LOGI("[%s]", __FUNCTION__);
	PLAYER_INSTANCE_CHECK(player);
	player_s * handle = (player_s *) player;
	PLAYER_STATE_CHECK(handle,PLAYER_STATE_IDLE);

	int ret = mm_player_set_safety_volume(handle->mm_handle);
	if(ret != MM_ERROR_NONE)
	{
		return __convert_error_code(ret,(char*)__FUNCTION__);
	}

	return ret;
}

bool  __audio_stream_callback_ex(MMPlayerAudioStreamDataType *stream, void *user_data)
{
	player_s * handle = (player_s*)user_data;
	if( handle->user_cb[_PLAYER_EVENT_TYPE_AUDIO_FRAME] )
	{
		if(handle->state==PLAYER_STATE_PLAYING || handle->state==PLAYER_STATE_PAUSED)
		{
			((player_audio_frame_decoded_cb_ex)handle->user_cb[_PLAYER_EVENT_TYPE_AUDIO_FRAME])((player_audio_raw_data_s *)stream, handle->user_data[_PLAYER_EVENT_TYPE_AUDIO_FRAME]);
		}
		else
		{
			LOGE("[%s] Skip stream - current state : %d", __FUNCTION__,handle->state);
		}
	}
	return TRUE;
}

int player_set_audio_frame_decoded_cb_ex(player_h player, player_audio_frame_decoded_cb_ex callback, void *user_data)
{
	PLAYER_INSTANCE_CHECK(player);
	PLAYER_NULL_ARG_CHECK(callback);
	player_s * handle = (player_s *) player;
	PLAYER_STATE_CHECK(handle, PLAYER_STATE_IDLE);

	int ret = mm_player_set_audio_stream_callback_ex(handle->mm_handle, __audio_stream_callback_ex, (void*)handle);
	if(ret != MM_ERROR_NONE)
		return __convert_error_code(ret,(char*)__FUNCTION__);

	PLAYER_SET_CALLBACK(_PLAYER_EVENT_TYPE_AUDIO_FRAME, handle, callback, user_data);
	return PLAYER_ERROR_NONE;
}

int player_unset_audio_frame_decoded_cb_ex(player_h player)
{
	PLAYER_INSTANCE_CHECK(player);
	player_s * handle = (player_s *) player;

	handle->user_cb[_PLAYER_EVENT_TYPE_AUDIO_FRAME] = NULL;
	handle->user_data[_PLAYER_EVENT_TYPE_AUDIO_FRAME] = NULL;
	LOGI("[%s] Event type : %d ",__FUNCTION__, _PLAYER_EVENT_TYPE_AUDIO_FRAME);

	int ret = mm_player_set_audio_stream_callback_ex(handle->mm_handle, NULL, NULL);
	if(ret != MM_ERROR_NONE)
		return __convert_error_code(ret,(char*)__FUNCTION__);
	else
		return PLAYER_ERROR_NONE;
}

int player_set_missed_plugin_info_cb(player_h player, player_missed_plugin_info_cb callback, void * user_data)
{
	PLAYER_INSTANCE_CHECK(player);
	PLAYER_NULL_ARG_CHECK(callback);
	player_s * handle = (player_s *) player;

	PLAYER_SET_CALLBACK(_PLAYER_EVENT_TYPE_MISSED_PLUGIN, handle, callback, user_data);
	return PLAYER_ERROR_NONE;
}

int player_use_streaming_private_buffering_mode(player_h player, player_buffering_mode_priv_e mode)
{
	PLAYER_INSTANCE_CHECK(player);

	player_s * handle = (player_s *) player;
	if (!__player_state_validate(handle, PLAYER_STATE_IDLE))
	{
		LOGE("[%s] PLAYER_ERROR_INVALID_STATE(0x%08x) : current state - %d" ,__FUNCTION__,PLAYER_ERROR_INVALID_STATE, handle->state);
		return PLAYER_ERROR_INVALID_STATE;
	}

	if (mode == PLAYER_BUFFERING_MODE_SLINK)
	{
		int ret = mm_player_set_runtime_buffering_mode(handle->mm_handle, MM_PLAYER_BUFFERING_MODE_SLINK, 0);
		if(ret != MM_ERROR_NONE)
			return __convert_error_code(ret,(char*)__FUNCTION__);
	}
	else
	{
		return PLAYER_ERROR_INVALID_PARAMETER;
	}

	return PLAYER_ERROR_NONE;

}

int player_exclude_audio(player_h player , bool enable)
{
	PLAYER_INSTANCE_CHECK(player);
	player_s * handle = (player_s *) player;

	int ret = mm_player_set_exclude_audio(handle->mm_handle, enable);
	if(ret != MM_ERROR_NONE)
	{
		return __convert_error_code(ret,(char*)__FUNCTION__);
	}
	else
	{
		return PLAYER_ERROR_NONE;
	}
}

int player_is_audio_excluded(player_h player, bool *no_audio)
{
	PLAYER_INSTANCE_CHECK(player);
	PLAYER_NULL_ARG_CHECK(no_audio);
	player_s * handle = (player_s *) player;

	int ret = mm_player_get_exclude_audio(handle->mm_handle, no_audio);
	if(ret != MM_ERROR_NONE)
	{
		return __convert_error_code(ret,(char*)__FUNCTION__);
	}
	else
	{
		return PLAYER_ERROR_NONE;
	}
}

#define _VWPLAYER_FREEIF(x) \
do { \
	if ( x ) \
		g_free( x ); \
	x = NULL; \
} while(0)

static gboolean _init_gstreamer(void)
{
	static gboolean initialized = FALSE;
	static const int max_argc = 50;
	gint* argc = NULL;
	gchar** argv = NULL;
	gchar** argv2 = NULL;
	GError *err = NULL;
	int i = 0;
	int arg_count = 0;

	if ( initialized ) {
		LOGI("gstreamer already initialized.\n");
		return TRUE;
	}

	/* alloc */
	argc = malloc( sizeof(int) );
	argv = malloc( sizeof(gchar*) * max_argc );
	argv2 = malloc( sizeof(gchar*) * max_argc );

	if ( !argc || !argv )
		goto ERROR;

	memset( argv, 0, sizeof(gchar*) * max_argc );
	memset( argv2, 0, sizeof(gchar*) * max_argc );

	/* add initial */
	*argc = 1;
	argv[0] = g_strdup( "video-wall-player" );


	/* we would not do fork for scanning plugins */
	argv[*argc] = g_strdup("--gst-disable-registry-fork");
	(*argc)++;

	LOGI("initializing gstreamer with following parameter\n");
	LOGI("argc : %d\n", *argc);
	arg_count = *argc;

	for ( i = 0; i < arg_count; i++ ) {
		argv2[i] = argv[i];
		LOGI("argv[%d] : %s\n", i, argv2[i]);
	}

	/* initializing gstreamer */
	if ( ! gst_init_check (argc, &argv, &err)) {
		LOGE("Could not initialize GStreamer: %s\n", err ? err->message : "unknown error occurred");
		if (err) {
			g_error_free (err);
		}

		goto ERROR;
	}

	/* release */
	for ( i = 0; i < arg_count; i++ ) {
		LOGI("release - argv[%d] : %s\n", i, argv2[i]);
		_VWPLAYER_FREEIF( argv2[i] );
	}

	_VWPLAYER_FREEIF( argv );
	_VWPLAYER_FREEIF( argv2 );
	_VWPLAYER_FREEIF( argc );

	/* done */
	initialized = TRUE;

	return TRUE;

ERROR:

	/* release */
	for ( i = 0; i < arg_count; i++ ) {
		LOGI("free[%d] : %s\n", i, argv2[i]);
		_VWPLAYER_FREEIF( argv2[i] );
	}

	_VWPLAYER_FREEIF( argv );
	_VWPLAYER_FREEIF( argv2 );
	_VWPLAYER_FREEIF( argc );

	return FALSE;
}

void player_preinit_plugins()
{
	int items = 0;
	int i = 0;
	GstPlugin *newplugin;

	#define _GST_PLUGIN_PATH "/usr/lib/gstreamer-0.10/"
	#define _ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))

	const char* load_list[] =
	{
			_GST_PLUGIN_PATH"libgstcoreelements.so",
			_GST_PLUGIN_PATH"libgsttypefindfunctions.so",
			_GST_PLUGIN_PATH"libgstisomp4.so",
			_GST_PLUGIN_PATH"libgstsavsdech264.so",
			_GST_PLUGIN_PATH"libgstxvimagesink.so",
			_GST_PLUGIN_PATH"libgstaudioparsers.so",
			_GST_PLUGIN_PATH"libgstsavsdecaac.so",
			_GST_PLUGIN_PATH"libgstavsyssink.so",
			_GST_PLUGIN_PATH"libgstcoreindexers.so",
	};

	items = _ARRAY_SIZE(load_list);

	_init_gstreamer();

	for ( i = 0; i < items; i++ ) {
		newplugin = gst_plugin_load_file(load_list[i], NULL);

		if (newplugin) {
			    gst_object_unref (newplugin);
		} else {
			LOGE("failed to load %s", load_list[i]);
		}
	}
}

int player_set_prelistening_mode(player_h player, player_prelistening_mode_e mode)
{
	PLAYER_INSTANCE_CHECK(player);
	player_s * handle = (player_s *) player;
	PLAYER_STATE_CHECK(handle,PLAYER_STATE_IDLE);

	int ret = mm_player_set_session_prelistening(handle->mm_handle, mode);
	if(ret != MM_ERROR_NONE)
		return __convert_error_code(ret,(char*)__FUNCTION__);
	else
		return PLAYER_ERROR_NONE;
}
