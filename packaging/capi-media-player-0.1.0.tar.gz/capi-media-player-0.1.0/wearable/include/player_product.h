/*
* Copyright (c) 2011 Samsung Electronics Co., Ltd All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#ifndef __TIZEN_MEDIA_PLAYER_PRODUCT_H__
#define	__TIZEN_MEDIA_PLAYER_PRODUCT_H__
#include <player.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
	void *data;
	int size;
	int channel;
	int rate;
	int depth;
	bool little_endian;
}player_audio_raw_data_s;

typedef enum
{
	PLAYER_MISSED_PLUGIN_UNKNOWN = 0,
	PLAYER_MISSED_PLUGIN_VIDEO_DECODER,
	PLAYER_MISSED_PLUGIN_AUDIO_DECODER,
} player_missed_plugin_type_e;

/**
 * @brief Enumerations of private buffering mode
 */
typedef enum
{
	PLAYER_BUFFERING_MODE_SLINK = 0,
} player_buffering_mode_priv_e;

/**
 * @brief
 * Enumerations of pre-listening mode
 */
typedef enum
{
	PLAYER_PRELISTENING_MODE_RINGTONE = 0,
	PLAYER_PRELISTENING_MODE_NOTIFICATION,
	PLAYER_PRELISTENING_MODE_ALARM,
	PLAYER_PRELISTENING_MODE_MEDIA,
} player_prelistening_mode_e;


/**
 * @brief  Called when the audio frame is decoded.
 * @param[in]   audio_raw_frame	The decoded audio frame data type
 * @param[in]   user_data	The user data passed from the callback registration function
 * @see player_set_audio_frame_decoded_cb()
 * @see player_unset_audio_frame_decoded_cb()
 */
typedef void (*player_audio_frame_decoded_cb_ex)(player_audio_raw_data_s *audio_raw_frame, void *user_data);

/**
 * @brief  Called when there is no supported plugin.
 * @param[in]	type  missed plugin type
 * @param[in]	messages can be passed but, it can be null.
 * @param[in]	user_data	The user data passed from the callback registration function
 * @see
 * @see #player_missed_plugin_type_e
 */
typedef void (*player_missed_plugin_info_cb)(player_missed_plugin_type_e type, char* message, void *user_data);

/**
 * @brief Sets the playback rate without pitch change
 * @details The default value is 1.0.
 * @remarks
 * @remarks No operation is performed, if @a rate is 0.
 * @param[in]   player The handle to media player
 * @param[in]   rate The playback rate of audio(0.5x ~ 2.0x), video(0.5x ~ 1.5x)
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 * @retval #PLAYER_ERROR_INVALID_STATE Invalid player state
 * @pre The player state must be one of these: #PLAYER_STATE_READY, #PLAYER_STATE_PLAYING, or #PLAYER_STATE_PAUSED.
 */
int player_set_playback_rate_ex(player_h player, float rate);

/**
 * @brief
 * @remarks
 * @remarks
 * @param[in]   player The handle to media player
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_STATE Invalid player state
 * @pre  The player state should be #PLAYER_STATE_IDLE
 */
int player_set_rich_audio(player_h player);

/**
 * @brief
 * @remarks
 * @remarks
 * @param[in]   player The handle to media player
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_STATE Invalid player state
 * @pre  The player state should be #PLAYER_STATE_IDLE
 */
int player_set_safety_volume(player_h player);

/**
 * @brief Registers a callback function to be invoked when audio frame is decoded.
 * @param[in] player	The handle to media player
 * @param[in] start The start position to decode.
 * @param[in] end	The end position to decode.
 * @param[in] callback	The callback function to register
 * @param[in] user_data	The user data to be passed to the callback function
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 * @pre The player state must be #PLAYER_STATE_IDLE by player_create() or player_unprepare().
 * @post  player_audio_frame_decoded_cb_ex() will be invoked
 * @see player_unset_audio_frame_decoded_cb_ex()
 */
int player_set_audio_frame_decoded_cb_ex(player_h player, player_audio_frame_decoded_cb_ex callback, void *user_data);

/**
 * @brief Unregisters the callback function.
 * @param[in] player The handle to media player
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 * @see player_set_audio_frame_decoded_cb()
 */
int player_unset_audio_frame_decoded_cb_ex(player_h player);

/**
 * @brief Registers a callback function to be invoked when there is not supported plugin.
 * @param[in] player	The handle to media player
 * @param[in] callback	The callback function to register
 * @param[in] user_data	The user data to be passed to the callback function
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 * @post  player_error_cb() will be invoked
 * @see player_unset_error_cb()
 * @see player_error_cb()
 */
int player_set_missed_plugin_info_cb(player_h player, player_missed_plugin_info_cb callback, void * user_data);

/**
 * @brief Use the private buffering mode for streaming playback.
 * @remarks This API is applicable to HTTP streaming.
 * @param[in] player The handle to media player
 * @param[in] mode The mode of buffering
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 * @retval #PLAYER_ERROR_INVALID_STATE Invalid player state
 * @pre The player state must be one of these: #PLAYER_STATE_IDLE, #PLAYER_STATE_READY, #PLAYER_STATE_PLAYING, or #PLAYER_STATE_PAUSED.
 */
int player_use_streaming_private_buffering_mode(player_h player, player_buffering_mode_priv_e mode);

/**
 * @brief  Player excludes audio.
 * @remarks Player plays only video without audio. audio decoding is not executed.
 * @param[in] player The handle to media player
 * @param[in] enable if enable is true, exclude audio.
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 */
int player_exclude_audio(player_h player, bool enable);

/**
 * @brief Gets whether player excludes audio or not
 * @param[in]   player The handle to media player
 * @param[out]  no_audio (@c true = audio can not be decoded, @c false = audio can be decoded)
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_OPERATION Invalid operation
 */
int player_is_audio_excluded(player_h player, bool *no_audio);

/**
 * @brief Change player session for pre-listening mode.
 * @param[in] player The handle to media player
 * @param[in] mode pre-listening mode for session
 * @return 0 on success, otherwise a negative error value.
 * @retval #PLAYER_ERROR_NONE Successful
 * @retval #PLAYER_ERROR_INVALID_PARAMETER Invalid parameter
 * @retval #PLAYER_ERROR_INVALID_STATE Invalid player state
 * @retval #PLAYER_ERROR_SOUND_POLICY Sound policy error
 * @pre The player state should be #PLAYER_STATE_IDLE by player_create() or player_unprepare().
 * @see
 */
int player_set_prelistening_mode(player_h player, player_prelistening_mode_e mode);

void player_preinit_plugins();

#ifdef __cplusplus
}
#endif

#endif //__TIZEN_MEDIA_PLAYER_PRODUCT_H__


